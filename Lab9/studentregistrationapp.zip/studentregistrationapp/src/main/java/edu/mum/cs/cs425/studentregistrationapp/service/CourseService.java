package edu.mum.cs.cs425.studentregistrationapp.service;

import edu.mum.cs.cs425.studentregistrationapp.model.Course;

public interface CourseService {
    Course save(Course course);
}
