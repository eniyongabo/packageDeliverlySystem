package edu.mum.cs.cs425.studentregistrationapp.service;

import edu.mum.cs.cs425.studentregistrationapp.model.Transcript;

public interface TranscriptService {
    public Transcript save(Transcript t);
}
